import random

def check_opportunity():
    # Simulated logic: 10% chance of signal
    trigger = random.random() > 0.9
    return {
        "trade_signal": trigger,
        "confidence": round(random.uniform(0.5, 0.95), 2),
        "pair": "ETH/USDC"
    }
