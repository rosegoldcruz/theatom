import time
import json
from strategy import check_opportunity

def run():
    while True:
        signal = check_opportunity()
        with open('signals.json', 'w') as f:
            json.dump(signal, f)
        print(f"ADOM Signal: {signal}")
        time.sleep(10)

if __name__ == "__main__":
    run()
